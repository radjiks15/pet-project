# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: Negative-scope/petTests.spec.ts >> Update pet - without required NAME field
- Location: tests/Negative-scope/petTests.spec.ts:45:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 405
Received: 200
```

# Test source

```ts
  1 | import { APIResponse, expect } from "@playwright/test";
  2 | 
  3 | export function expectStatus(response: APIResponse, expectStatus:number): void {
> 4 |         expect(response.status()).toBe(expectStatus);
    |                                   ^ Error: expect(received).toBe(expected) // Object.is equality
  5 |  }
```