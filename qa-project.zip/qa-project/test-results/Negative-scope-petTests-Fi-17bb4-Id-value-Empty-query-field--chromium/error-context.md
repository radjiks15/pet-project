# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: Negative-scope/petTests.spec.ts >> Find pet by ID with invalid petId value: Empty query field 
- Location: tests/Negative-scope/petTests.spec.ts:244:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 400
Received: 405
```

# Test source

```ts
  147 |     const createResponse = await petClient.addPet(pet);
  148 |     await validateResponse<Pet>(createResponse,200,petCreatedSchema);
  149 |     const validUpdateBody = generateUpdatedPet(pet.id);
  150 |     const invalidUpdateBody = {...validUpdateBody, tags:'string'};
  151 |     const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
  152 |     await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));
  153 | 
  154 | });
  155 | 
  156 | test('Update pet - tags is object', async ({request}) => { 
  157 |     const petClient = new PetClient(request);
  158 |     const pet = generatePet();
  159 |     const createResponse = await petClient.addPet(pet);
  160 |     await validateResponse<Pet>(createResponse,200,petCreatedSchema);
  161 |     const validUpdateBody = generateUpdatedPet(pet.id);
  162 |     const invalidUpdateBody = {...validUpdateBody, tags:{}};
  163 |     const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
  164 |     await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));
  165 | 
  166 | });
  167 | 
  168 | test('Update pet - tags.id is not number', async ({request}) => { 
  169 |     const petClient = new PetClient(request);
  170 |     const pet = generatePet();
  171 |     const createResponse = await petClient.addPet(pet);
  172 |     await validateResponse<Pet>(createResponse,200,petCreatedSchema);
  173 |     const validUpdateBody = generateUpdatedPet(pet.id);
  174 |     const invalidUpdateBody = {...validUpdateBody, tags:[{id:'invalid',name:'string'}]};
  175 |     const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
  176 |     await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));
  177 | });
  178 | test('Update pet - tags.name is not a string', async ({request}) => { 
  179 |     const petClient = new PetClient(request);
  180 |     const pet = generatePet();
  181 |     const createResponse = await petClient.addPet(pet);
  182 |     await validateResponse<Pet>(createResponse,200,petCreatedSchema);
  183 |     const validUpdateBody = generateUpdatedPet(pet.id);
  184 |     const invalidUpdateBody = {...validUpdateBody, tags:[{id:123,name:123}]};
  185 |     const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
  186 |     await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));
  187 | });
  188 | 
  189 | test('Update pet - status is invalid enum value', async ({request}) => { 
  190 |     const petClient = new PetClient(request);
  191 |     const pet = generatePet();
  192 |     const createResponse = await petClient.addPet(pet);
  193 |     await validateResponse<Pet>(createResponse,200,petCreatedSchema);
  194 |     const validUpdateBody = generateUpdatedPet(pet.id);
  195 |     const invalidUpdateBody = {...validUpdateBody, status:'ready'};
  196 |     const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
  197 |     await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));
  198 | });
  199 | 
  200 | 
  201 | 
  202 | // for (const testCase of invalidUpdateCases()) {
  203 | 
  204 | //     test(`Updating pet with invalud data: ${testCase.name}`, async ({request}) => {
  205 | //         const petClient = new PetClient(request);
  206 | //         const pet = generatePet();
  207 | //         const createResponse = await petClient.addPet(pet);
  208 | //         await validateResponse<Pet>(createResponse,200,petCreatedSchema);
  209 | //         const response = await petClient.updatePetRaw(testCase.body);
  210 | //         const data = await validateResponse<updateInvalidPetResponse>(response,405,apiErrorSchema(405))
  211 | //     });
  212 | // };
  213 | 
  214 | // test('Updating pet with non existing pet id', async ({request}) => {
  215 | //         const petClient = new PetClient(request);
  216 | //         const pet = generatePet();
  217 | //         const createResponse = await petClient.addPet(pet);
  218 | //         await validateResponse<Pet>(createResponse,200,petCreatedSchema);
  219 | //         const delitingResponse = await petClient.deletePetById(pet.id);
  220 | //         await validateResponse<DeleteBody>(delitingResponse,200,petDeletedSchema);
  221 | //         const updatingResponse = await petClient.updatePet(pet);
  222 | //         const updatingdata = await validateResponse<updateInvalidPetResponse>(updatingResponse,404,apiErrorSchema(404));
  223 | //         const getAfterDelete = await petClient.petById(pet.id);
  224 | //         expect(getAfterDelete.status()).toBe(404);
  225 |     
  226 | //     });
  227 | 
  228 | for (const status of petStatus) { 
  229 |     test(`Find pet by Status with invalid status value for: ${status.status}`, async ({request}) => {
  230 |         const petClient = new PetClient(request);
  231 |         const response = await petClient.petByStatusRaw(status.status);
  232 |         expect(response.status()).toBe(400);
  233 | });
  234 | };
  235 | 
  236 | test('Find pet by Status whitout required query {STATUS}', async ({request}) => {
  237 |     const petClient = new PetClient(request);
  238 |     const response = await petClient.petByStatusWithoutQueryRaw();
  239 |     expect(response.status()).toBe(404);
  240 | });
  241 | 
  242 | 
  243 | for (const petId of PetId) { 
  244 | test (`Find pet by ID with invalid petId value: ${petId.name} `, async ({request}) => {
  245 |     const petClient = new PetClient(request);
  246 |     const response = await petClient.petByIdRaw(petId.id)
> 247 |     expect(response.status()).toBe(400)
      |                               ^ Error: expect(received).toBe(expected) // Object.is equality
  248 | });
  249 | };
  250 | 
  251 | test('Find pet by ID with not existing pet ID', async ({request}) => {
  252 |     const petClient = new PetClient(request);
  253 |     const response = await petClient.petById(12312123123);
  254 |     expect(response.status()).toBe(404);
  255 | });
  256 | 
  257 | test('Find pet by IS without required {petId} query', async ({request}) => { 
  258 |     const petClient = new PetClient(request);
  259 |     const response = await petClient.petByIdWithoutQueryRaw();
  260 |     expect(response.status()).toBe(404);
  261 | })
  262 | 
  263 | for (const petId of PetId) { 
  264 | test(`Delete pet by ID with invalid ID value: ${petId.name}`, async ({request}) => { 
  265 |     const petClient = new PetClient(request);
  266 |     const response = await petClient.deletePetByIdRaw(petId.id)
  267 |     expect(response.status()).toBe(400)
  268 | })}
  269 | 
  270 | test('Delete pet by ID with not existing pet ID', async ({request}) => {
  271 |     const petClient = new PetClient(request);
  272 |     const response = await petClient.deletePetById(12312123123);
  273 |     expect(response.status()).toBe(404);
  274 | });
  275 | 
  276 | test('Delete pet with valid petId but without vali api_key', async ({request}) => { 
  277 |     const petClient = new PetClient(request);
  278 |     const response = await petClient.deletePetByIdWithoutApikeyRaw(1);
  279 |     expect(response.status()).toBe(401); //или 403, по спеке не ясно
  280 | });
  281 | 
  282 | test('Delete pet without required {petId} query', async ({request}) => {
  283 |     const petClient = new PetClient(request);
  284 |     const response = await petClient.deletePetByIdWithoutQueryRaw();
  285 |     expect(response.status()).toBe(404);
  286 | });
  287 | 
  288 | 
  289 | 
  290 | 
  291 | 
  292 | 
  293 | 
```