export interface storeOrder {
    id: number;
    petId: number;
    quantity: number;
    shipDate: string;
    status: "placed" | "approved" | "delivered";
    complete: boolean
};

export type InventoryResponse = Record<string, number>;

export interface fetchOrderById {
    id: number;
    petId: number;
    quantity: number;
    shipDate: string;
    status: "placed" | "approved" | "delivered";
    complete: boolean
};

export interface DeleteOrder {
    code: number;
    type: string;
    message: string
};
