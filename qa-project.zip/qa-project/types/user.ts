export interface User {
    id: number;
    username: string;
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    phone: string;
    userStatus: number
};

export interface CreateUserResponse {
    code: number;
    type: string;
    message: string;
};

export interface getUserResponse {
    id: number;
    username: string;
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    phone: string;
    userStatus: number
};

export interface updateUserResponse {
    code: number;
    type: string;
    message: string;
};

export interface deleteUserResponse {
    code: number;
    type: string;
    message: string
};

export interface userLoginResponse {
    code: number;
    type: string;
    message: string
};

export interface userLogoutResponse {
    code: number;
    type: string;
    message: string
}; 




