

export type InvalidPet = {
    name: string;
    body: Record<string, unknown>;
    expectedStatus: number;
};


export interface Category {
    id: number;
    name: string
};

export interface Tag {
    id: number;
    name: string
}

export interface Pet {
    id: number;
    category: Category;
    name: string;
    photoUrls: string[];
    tags: Tag[];
    status: "available" | "pending" | "sold"
};  

export interface EmptyBody {};

export interface DeleteBody {
    code: number;
    type: string;
    message: string
}

export interface createInvalidPetResponse {
    code: number;
    type: string;
    message: string;
};

export interface updateInvalidPetResponse {
    code: number;
    type: string;
    message: string;
};


