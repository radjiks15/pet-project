import {User} from '../../types/user'

export function generateUser(): User {
    const timestamp = Date.now();
    const id = Math.floor(Math.random() * 1_000_000) + 1;

    return {
        id,
        username: `user_${timestamp}`,
        firstName: `firstName_${timestamp}`,
        lastName: `lastName_${timestamp}`,
        email: `user_${timestamp}@mail.com`,
        password: `pass_${timestamp}`,
        phone: `+380${id}`,
        userStatus: 1
    };
};

export function generateUpdatedUser(id: number): User {
    const timestamp = Date.now();

    return {
        id,
        username: `updated_user_${timestamp}`,
        firstName: `updated_firstName_${timestamp}`,
        lastName: `updated_lastName_${timestamp}`,
        email: `updated_${timestamp}@mail.com`,
        password: `updated_pass_${timestamp}`,
        phone: '+380123456789',
        userStatus: 1
    };
}


// export function generateUser():User {
//     return {
//   id: Date.now(),
//   username: `user_${Date.now()}`,
//   firstName: `fName_${Date.now()}`,
//   lastName: `lName_${Date.now()}`,
//   email: `user${Date.now()}@mail.com`,
//   password: `pass${Date.now()}`,
//   phone: `+${Date.now()}`,
//   userStatus: Math.floor(Math.random() * 10)
//     }
//  };

//  export function generateUpdatedUser():User {
//     return {
//   id: Date.now(),
//   username: `upd_user_${Date.now()}`,
//   firstName: `upd_fName_${Date.now()}`,
//   lastName: `upd_lName_${Date.now()}`,
//   email: `upd_user${Date.now()}@mail.com`,
//   password: `upd_pass${Date.now()}`,
//   phone: `+upd${Date.now()}`,
//   userStatus: Math.floor(Math.random() * 10)
//     }
//  };


//  export function generateUser():User {
//     return {
//   id: Date.now(),
//   username: `user ${Date.now()}`,
//   firstName: `fName ${Date.now()}`,
//   lastName: `lName ${Date.now()}`,
//   email: `user${Date.now()}@mail.com`,
//   password: `pass${Date.now()}`,
//   phone: `+${Date.now()}`,
//   userStatus: Date.now()
//     };
//  }