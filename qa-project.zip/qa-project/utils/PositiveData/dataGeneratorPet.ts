import {Pet} from '../../types/pet'

export function generateEmail() {
    return `user${Date.now()}@mail.com`;
}

export function generatePet(): Pet {
    const id = Date.now();

    return {
        id,
        category: {
            id: 1,
            name: 'dogs'
        },
        name: `dog-${id}`,
        photoUrls: [`photo-${id}`],
        tags: [
            {
                id: 1,
                name: 'automation'
            }
        ],
        status: 'available'
    };
} 

export function generateUpdatedPet(id:number):Pet {
    return {
        id,
        category: {
            id: 1,
            name: 'cats'
        },
        name: `cat-${id}`,
        photoUrls: [`photo-${id}`],
        tags: [
            {
                id: 1,
                name: 'updated'
            }
        ],
        status: 'pending'
    };
};
