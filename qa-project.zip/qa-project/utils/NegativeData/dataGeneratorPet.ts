import {generatePet, generateUpdatedPet} from '../../utils/PositiveData/dataGeneratorPet'
import { InvalidPet } from '../../types/NegativeTypes/pet';

export function invalidCreateCases():InvalidPet[] { 

    const pet = generatePet();
    const { name, ...petWithoutName } = pet;
    const petWithoutUrls = generatePet();
    const {photoUrls, ...petWithoutPhotoUrls} = petWithoutUrls

    return [
        {name: 'Request without request body',
        body: {},
        expectedStatus: 405
        },

        {name: 'id is string',
        body: {
            ...generatePet(),
            id: 'invalid'
        },
        expectedStatus: 405
        },

    {
        name: 'category.id is a string',
        body: {
            ...generatePet(),
            category: { id:'invalid',
                        name: 'dog'
                        }           
        },
        expectedStatus: 405
    },

    {name: 'category.name is a number',
        body: {
            ...generatePet(),
            category: { id: 1,
                        name: 1
                        }  
        },
        expectedStatus: 405
        },

    {
        name: 'name is a number',
        body: {
            ...generatePet(),
            name: 123         
        },
        expectedStatus: 405
    },
    {
        name: 'required name is missing',
        body: petWithoutName,
        expectedStatus: 405
    },
    {name: 'photoUrls is string instead of array',
        body: {
            ...generatePet(),
            photoUrls: 'invalid'
        },
        expectedStatus: 405
        },

    {
        name: 'photoUrls is object',
        body: {
            ...generatePet(),
            photoUrls: {}         
        },
        expectedStatus: 405
    },
    {name: 'required photoUrls is missing',
        body: petWithoutPhotoUrls,
        expectedStatus: 405
        }, 
    {name: 'tags is string instead of array',
        body: {
            ...generatePet(),
            tags: 'invalid'
        },
        expectedStatus: 405
        },

    {
        name: 'tags is object',
        body: {
            ...generatePet(),
            tags: {}          
        },
        expectedStatus: 405
    },
    {name: 'tags.id is not number',
        body: {
            ...generatePet(),
            tags:[{
                id:'invalid',
                name: 'name'
                }]
        },
        expectedStatus: 405
        },
    {name: 'tags.name is not a string',
        body: {
            ...generatePet(),
            tags:[{
                id:1,
                name: 123
                }]
        },
        expectedStatus: 405
        },
    {name: 'status is invalid enum value',
        body: {
            ...generatePet(),
            status: 'ready'
        },
        expectedStatus: 405
        },
    ]
};

export function invalidUpdateCases(petId:number):InvalidPet[] { 
    const validPet = generateUpdatedPet(petId);
    const pet = generateUpdatedPet(1);
    const { name, ...petWithoutName } = pet;
    const petWithputUrls = generateUpdatedPet(1);
    const {photoUrls, ...petWithoutPhotoUrls} = petWithputUrls
            
    return [
        {name: 'Request without request body',
        body: {},
        expectedStatus: 405
        },

        {name: 'id is string',
        body: {
            ...generateUpdatedPet(1),
            id: 'invalid'
        },
        expectedStatus: 400
        },

    {
        name: 'category.id is a string',
        body: {
            ...generateUpdatedPet(1),
            category: { id:'invalid',
                        name: 'dog'
                        }           
        },
        expectedStatus: 405
    },
    {name: 'category.name is a number',
        body: {
            ...generateUpdatedPet(1),
            category: { id: 1,
                        name: 1
                        }  
        },
        expectedStatus: 405
        },

    {
        name: 'name is a number',
        body: {
            ...generateUpdatedPet(1),
            name: 123         
        },
        expectedStatus: 405
    },
    {
        name: 'required name is missing',
        body: petWithoutName,
        expectedStatus: 405
    },
    {name: 'photoUrls is string instead of array',
        body: {
            ...generateUpdatedPet(1),
            photoUrls: 'invalid'
        },
        expectedStatus: 405
        },

    {
        name: 'photoUrls is object',
        body: {
            ...generateUpdatedPet(1),
            photoUrls: {}         
        },
        expectedStatus: 405
    },
    {name: 'required photoUrls is missing',
        body:petWithoutPhotoUrls,
        expectedStatus: 405
        },
    {name: 'tags is string instead of array',
        body: {
            ...generateUpdatedPet(1),
            tags: 'invalid'
        },
        expectedStatus: 405
        },

    {
        name: 'tags is object',
        body: {
            ...generateUpdatedPet(1),
            tags: {}          
        },
        expectedStatus: 405
    },
    {name: 'tags.id is not number',
        body: {
            ...generateUpdatedPet(1),
            tags:[{
                id:'invalid',
                name: 'name'
                }]
        },
        expectedStatus: 405
        },
    {name: 'tags.name is not a string',
        body: {
            ...generateUpdatedPet(1),
            tags:[{
                id:1,
                name: 123
                }]
        },
        expectedStatus: 405
        },
    {name: 'status is invalid enum value',
        body: {
            ...generateUpdatedPet(1),
            status: 'ready'
        },
        expectedStatus: 405
        }
    ]
}

