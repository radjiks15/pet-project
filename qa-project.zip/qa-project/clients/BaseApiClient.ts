import { APIRequestContext, APIResponse } from "@playwright/test";

export class BaseApiClient { 
    constructor (
        protected readonly request:APIRequestContext
    ) {}

    protected async get(url:string): Promise<APIResponse> {
        try{
            return await this.request.get(url);
        } catch(error) {
            console.log(`GET ${url} failed`);
            throw error;
                }
            };
    
    protected async post<T>(url:string, body:T): Promise<APIResponse> {
        try {
            return await this.request.post(url, {data:body});
        } catch (error) {
            console.log(`POST ${url} failed`);
            throw error;
                }
            };
    protected async put<T>(url:string, body:T): Promise<APIResponse> {
        try{ 
            return await this.request.put(url,{data:body});
        } catch (error) {
            console.log(`PUT ${url} failed`);
            throw error;
                }
            };
    
    protected async delete(url:string,  options?: { headers?: Record<string, string> }):Promise<APIResponse> {
        try{ 
            return await this.request.delete(url, options);
        } catch (error) {
            console.log(`DELETE ${url} failed`);
            throw error;
        }
    }
}

