import { APIRequestContext, APIResponse } from "@playwright/test";
import { BaseApiClient } from "./BaseApiClient";
import { Pet, EmptyBody} from "../types/pet"
import {env} from '../config/env'
export class PetClient extends BaseApiClient {
    constructor (request:APIRequestContext) {
        super(request);
    }

async addPet(body:Pet): Promise<APIResponse> {
    return this.post('pet', body);
};

async updatePet(body:Pet): Promise<APIResponse> {
    return this.put('pet', body);
};

async petByStatus(status: Pet['status']): Promise<APIResponse> { 
    return this.get(`pet/findByStatus/?status=${status}`); //available pending sold
};

async petById(queryUpdatePetId:number): Promise<APIResponse> {
    return this.get(`pet/${queryUpdatePetId}`);
};

async deletePetById(petIdforDelete:number): Promise<APIResponse> {
    return this.delete(`pet/${petIdforDelete}`, {headers: {api_key: env.apiKey}}); //тут нужно апи ключ добавить 
};

// Реквесты для инвалидных кейсов
async appPetRaw(body:Record<string, unknown>):Promise<APIResponse> {
    return this.post('pet', body);
};

async updatePetRaw(body:Record<string, unknown>):Promise<APIResponse> {
    return this.put('pet', body);
};

async petByStatusRaw(status:string): Promise<APIResponse> {
    return this.get(`pet/findByStatus/?status=${status}`);
};

async petByStatusWithoutQueryRaw(): Promise<APIResponse> {
    return this.get(`pet/findByStatus`);
};

async petByIdRaw(petId: string | number): Promise<APIResponse> {
    return this.get(`pet/${petId}`);
};

async petByIdWithoutQueryRaw(): Promise <APIResponse> {
    return this.get('pet/');
};

async deletePetByIdRaw(petId:string | number): Promise<APIResponse> {
    return this.delete(`pet/${petId}`, {headers: {api_key: env.apiKey}}); //тут нужно апи ключ добавить 
};

async deletePetByIdWithoutApikeyRaw(petIdforDelete:number): Promise<APIResponse> {
    return this.delete(`pet/${petIdforDelete}`); //тут нужно апи ключ добавить 
};

async deletePetByIdWithoutQueryRaw(): Promise<APIResponse> { 
    return this.delete(`pet/`);
};







//async updatePetByQuery(body:EmptyBody): Promise<APIResponse> {
//    return this.post(`pet/${queryUpdatePetId}?${queryUpdateStatus}&${queryUpdateName}`, body);
//};
}