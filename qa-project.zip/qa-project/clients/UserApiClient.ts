import { BaseApiClient } from "./BaseApiClient";
import { APIRequestContext, APIResponse } from "@playwright/test";
import { User } from "../types/user";

export class UserClass extends BaseApiClient {
    constructor (request:APIRequestContext) {
        super(request)
    };

    async createUser(body:User):Promise <APIResponse> { 
        return this.post('user',body);
    };

    async getUserByName(username:string): Promise <APIResponse> {
        return this.get(`user/${username}`);
    };

    async userLogin(username:string,userpassword:string):Promise <APIResponse> {
        return this.get(`user/login?username=${username}&password=${userpassword}`);
    };

    async userLogout():Promise <APIResponse> {
        return this.get('user/logout');
    };

    async userUpdate(username:string, body:User):Promise <APIResponse> {
        return this.put(`user/${username}`, body);
    };

    async userDelete(username:string):Promise <APIResponse> {
        return this.delete(`user/${username}`);
    };

}