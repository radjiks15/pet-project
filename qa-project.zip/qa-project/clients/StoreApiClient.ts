import { BaseApiClient } from "./BaseApiClient";
import { APIRequestContext, APIResponse } from "@playwright/test";
import { storeOrder } from "../types/store";

export class StoreClient extends BaseApiClient {
    constructor (request:APIRequestContext) {
        super(request)
    }

async placeOrder(body:storeOrder): Promise<APIResponse> { 
    return this.post('store/order', body);
};

async petsStatusCodes(): Promise<APIResponse> {
    return this.get('store/inventory');
};

async getByOrderId(orderId:number): Promise<APIResponse> {
    return this.get(`store/order/${orderId}`); //>=1 & <=10
};

async deleteByOrderId(orderId:number): Promise<APIResponse> {
    return this.delete(`store/order/${orderId}`);
};













}










