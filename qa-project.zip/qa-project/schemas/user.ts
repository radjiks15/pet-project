export const createUserSchema = {
    type: 'object',
    
    required: [
        'code',
        'type',
        'message'
    ],
    properties: {
        code: {
            type: 'number',
            enum: [200]
        },
        
        type: {
            type: 'string'
        },

        message: {
            type: 'string'
        }
    }
}

export const getUserByUsernameSchema = {
    type: 'object',

    required: [
        'id',
        'username',
        'firstName',
        'lastName',
        'email',
        'password',
        'phone',
        'userStatus'
    ],

    properties: {
        id: {
            type: 'number'
        },

        username: {
            type: 'string'
        },

        firstName: {
            type: 'string'
        },

        lastName: {
            type: 'string'
        },

        email: {
            type: 'string'
        },

        password: {
            type: 'string'
        },

        phone: {
            type: 'string'
        },

        userStatus: {
            type: 'number' 
        }
    }
};

export const updateUserSchema = createUserSchema;
export const deleteUserSchema = createUserSchema;
export const loginUserSchema = createUserSchema;
export const logoutUserSchema = createUserSchema;
