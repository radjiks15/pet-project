export const storeOrderSchema = {
    type: 'object',

    required: [
        'id',
        'petId',
        'quantity',
        'shipDate',
        'status',
        'complete'
    ],

    properties: {
        id: {
            type: 'number'
        },

        petId: {
            type: 'number'
        },

        quantity: {
            type: 'number'
        },

        shipDate: {
            type: 'string'
        },

        status: {
            type: 'string',
            enum: ['placed', 'approved', 'delivered']
        },

        complete: {
            type: 'boolean'
        }
    }
};

export const storeOrderDelSchema = {
    type: 'object',
    
    required: [
        'code',
        'type',
        'message'
    ],
    properties: {
        code: {
            type: 'number',
            enum: [200]
        },
        
        type: {
            type: 'string'
        },

        message: {
            type: 'string'
        }
    }
}

export const storeInventory = {
    type: 'object',
    additionalProperties: { 
        type: 'number'
    }
};

export const storeOrderById = {
    type: 'object',

    required: [
        'id',
        'petId',
        'quantity',
        'shipDate',
        'status',
        'complete'
    ],

    properties: {
        id: {
            type: 'number'
        },

        petId: {
            type: 'number'
        },

        quantity: {
            type: 'number'
        },

        shipDate: {
            type: 'string'
        },

        status: {
            type: 'string',
            enum: ['placed', 'approved', 'delivered']
        },

        complete: {
            type: 'boolean'
        }
    }
}