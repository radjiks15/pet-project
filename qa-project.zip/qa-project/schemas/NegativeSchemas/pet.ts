export function apiErrorSchema(code:number) {
    return { 
    
    type: 'object',
    
    required: ['code', 'type', 'message'],

    properties: {
        code: {
            type: 'number',
            enum:[code]
        },

        type: {
        type: 'string'
        },
        message: {
            type: 'string'
        }

    }

};}





