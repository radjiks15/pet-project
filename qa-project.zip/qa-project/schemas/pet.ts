export const petCreatedSchema = {
    type: 'object',

    required: [
        'id',
        'category',
        'name',
        'photoUrls',
        'tags',
        'status'
    ],

    properties: {

        id: { 
            type: 'number'
        },

        category: { 
            type: 'object',
            properties: {
                id: {type: 'number'},
                name: {type: 'string'}
        },
            required: ['id', 'name'],
    },

        name: {
            type: 'string'
        },

        photoUrls: {
            type: 'array',
            items: {
                type: 'string'
            }
        },
        
        tags: {
            type: 'array',
            items: {
                type: 'object',
                    properties: {
                        id: {type: 'number'},
                        name: {type: 'string'},
                    },
                    required: ['id', 'name']
                }
            },

        status: {
            type: 'string',
            enum: ['available', 'pending','sold']
        }
    }
};

export const petFindByIdSchema = {
    // type: 'array',
    // items : { 
        type: 'object',
                properties: {

        id: { 
            type: 'number'
        },

        category: { 
            type: 'object',
            properties: {
                id: {type: 'number'},
                name: {type: 'string'}
        },
            required: ['id'],
    },

        name: {
            type: 'string'
        },

        photoUrls: {
            type: 'array',
            items: {
                type: 'string'
            }
        },
        
        tags: {
            type: 'array',
            items: {
                type: 'object',
                    properties: {
                        id: {type: 'number'},
                        name: {type: 'string'},
                    },
                    required: ['id']
                }
            },

        status: {
            type: 'string',
            enum: ['available', 'pending','sold']
        }
    }};
// }};

export const petByStatusArraySchema = {
    type: 'array',
    items: {
        type: 'object',
        required: ['status'],
        properties: {
            status: {
                type: 'string',
                enum: ['available', 'pending', 'sold']
            }
        }
    }
};




export const petDeletedSchema = {
    type: 'object',
    
    required: [
        'code',
        'type',
        'message'
    ],
    properties: {
        code: {
            type: 'number',
            enum: [200]
        },
        
        type: {
            type: 'string'
        },

        message: {
            type: 'string'
        }
    }
}



