import 'dotenv/config';  

export const env = {
    baseUrl: process.env.BASE_URL ?? '',
    apiKey: process.env.PETSTORE_API_KEY ?? ''
};


