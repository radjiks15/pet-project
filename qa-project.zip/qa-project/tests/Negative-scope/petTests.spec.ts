import { test, expect } from '@playwright/test';
import { PetClient } from "../../clients/PetApiClient";
import { invalidCreateCases, invalidUpdateCases } from '../../utils/NegativeData/dataGeneratorPet';
import { validateResponse } from '../../helpers/validateResponse';
import { InvalidPet, createInvalidPetResponse, updateInvalidPetResponse} from '../../types/NegativeTypes/pet';
import { petCreatedSchema, petDeletedSchema } from '../../schemas/pet';
import { petStatus,PetId } from '../../fixtures/Negative-folder/pet';
import { petUpdateRequestBody } from '../../fixtures/pet';
import { generatePet, generateUpdatedPet } from '../../utils/PositiveData/dataGeneratorPet';
import { Pet, DeleteBody } from '../../types/pet';
import { expectSchema } from '../../helpers/expectSchema';
import { apiErrorSchema } from '../../schemas/NegativeSchemas/pet';
import { stripVTControlCharacters } from 'util';

for (const testCase of invalidCreateCases()) {

    test(`Creating pet with invalid data: ${testCase.name}`, async ({request}) => {
        const petClient = new PetClient(request);
        const response = await petClient.appPetRaw(testCase.body);
        const data = await validateResponse<createInvalidPetResponse>(response,405,apiErrorSchema(405));
        //expect(response.status()).toBe(testCase.expectedStatus)
        //expect(data.code).toBe(405);
        //expect(data.type).toBeTruthy();
        //expect(data.message).toBe(String());
    });
};


test.describe('Invalid update pet tests', () => {

    test('Update pet - name is number', async ({request}) => {
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const invalidUpdateBody = {...validUpdateBody, name: 123};
    const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));
});

test('Update pet - without required NAME field', async ({request}) => { 
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const {name, ...petWithoutName} = validUpdateBody;
    const invaludUpdateBody = {petWithoutName};
    const updateResponse = await petClient.updatePetRaw(petWithoutName);
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));

});

test('Update pet - request without requestbody', async ({request}) => {
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const invalidUpdateBody = {...validUpdateBody, body:{}};
    const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));
});



test('Update pet - id is string', async ({request}) => { 
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const invalidUpdateBody = {...validUpdateBody, id: 'invalid'};
    const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));

});

test('Update pet - category.id is a string', async ({request}) => { 
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const invalidUpdateBody = {...validUpdateBody, category:{id: 'invalid', name: 'string'}};
    const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));

});

test('Update pet - category.name is a number' , async ({request}) => { 
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const invalidUpdateBody = {...validUpdateBody, category:{id: 123, name: 123}};
    const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));

});

test('Update pet - photoUrls is string instead of array', async ({request}) => { 
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const invalidUpdateBody = {...validUpdateBody, photoUrls:'string'};
    const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));

});

test('Update pet - photoUrls is object instead of array', async ({request}) => { 
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const invalidUpdateBody = {...validUpdateBody, photoUrls:{}};
    const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));

});

test('Update pet - required photoUrls is missing', async ({request}) => { 
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const {photoUrls, ...petWithoutUrls} = validUpdateBody;
    const invaludUpdateBody = {petWithoutUrls};
    const updateResponse = await petClient.updatePetRaw(petWithoutUrls)
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));
    
});

test('Update pet - tags is string instead of array', async ({request}) => { 
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const invalidUpdateBody = {...validUpdateBody, tags:'string'};
    const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));

});

test('Update pet - tags is object', async ({request}) => { 
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const invalidUpdateBody = {...validUpdateBody, tags:{}};
    const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));

});

test('Update pet - tags.id is not number', async ({request}) => { 
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const invalidUpdateBody = {...validUpdateBody, tags:[{id:'invalid',name:'string'}]};
    const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));
});
test('Update pet - tags.name is not a string', async ({request}) => { 
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const invalidUpdateBody = {...validUpdateBody, tags:[{id:123,name:123}]};
    const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));
});

test('Update pet - status is invalid enum value', async ({request}) => { 
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
    await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const validUpdateBody = generateUpdatedPet(pet.id);
    const invalidUpdateBody = {...validUpdateBody, status:'ready'};
    const updateResponse = await petClient.updatePetRaw(invalidUpdateBody)
    await validateResponse<updateInvalidPetResponse>(updateResponse,405,apiErrorSchema(405));
});
});


// for (const testCase of invalidUpdateCases()) {

//     test(`Updating pet with invalud data: ${testCase.name}`, async ({request}) => {
//         const petClient = new PetClient(request);
//         const pet = generatePet();
//         const createResponse = await petClient.addPet(pet);
//         await validateResponse<Pet>(createResponse,200,petCreatedSchema);
//         const response = await petClient.updatePetRaw(testCase.body);
//         const data = await validateResponse<updateInvalidPetResponse>(response,405,apiErrorSchema(405))
//     });
// };

// test('Updating pet with non existing pet id', async ({request}) => {
//         const petClient = new PetClient(request);
//         const pet = generatePet();
//         const createResponse = await petClient.addPet(pet);
//         await validateResponse<Pet>(createResponse,200,petCreatedSchema);
//         const delitingResponse = await petClient.deletePetById(pet.id);
//         await validateResponse<DeleteBody>(delitingResponse,200,petDeletedSchema);
//         const updatingResponse = await petClient.updatePet(pet);
//         const updatingdata = await validateResponse<updateInvalidPetResponse>(updatingResponse,404,apiErrorSchema(404));
//         const getAfterDelete = await petClient.petById(pet.id);
//         expect(getAfterDelete.status()).toBe(404);
    
//     });

for (const status of petStatus) { 
    test(`Find pet by Status with invalid status value for: ${status.status}`, async ({request}) => {
        const petClient = new PetClient(request);
        const response = await petClient.petByStatusRaw(status.status);
        expect(response.status()).toBe(400);
});
};

test('Find pet by Status whitout required query {STATUS}', async ({request}) => {
    const petClient = new PetClient(request);
    const response = await petClient.petByStatusWithoutQueryRaw();
    expect(response.status()).toBe(404);
});


for (const petId of PetId) { 
test (`Find pet by ID with invalid petId value: ${petId.name} `, async ({request}) => {
    const petClient = new PetClient(request);
    const response = await petClient.petByIdRaw(petId.id)
    expect(response.status()).toBe(400)
});
};

test('Find pet by ID with not existing pet ID', async ({request}) => {
    const petClient = new PetClient(request);
    const response = await petClient.petById(12312123123);
    expect(response.status()).toBe(404);
});

test('Find pet by IS without required {petId} query', async ({request}) => { 
    const petClient = new PetClient(request);
    const response = await petClient.petByIdWithoutQueryRaw();
    expect(response.status()).toBe(404);
})

for (const petId of PetId) { 
test(`Delete pet by ID with invalid ID value: ${petId.name}`, async ({request}) => { 
    const petClient = new PetClient(request);
    const response = await petClient.deletePetByIdRaw(petId.id)
    expect(response.status()).toBe(400)
})}

test('Delete pet by ID with not existing pet ID', async ({request}) => {
    const petClient = new PetClient(request);
    const response = await petClient.deletePetById(12312123123);
    expect(response.status()).toBe(404);
});

test('Delete pet with valid petId but without vali api_key', async ({request}) => { 
    const petClient = new PetClient(request);
    const response = await petClient.deletePetByIdWithoutApikeyRaw(1);
    expect(response.status()).toBe(401); //или 403, по спеке не ясно
});

test('Delete pet without required {petId} query', async ({request}) => {
    const petClient = new PetClient(request);
    const response = await petClient.deletePetByIdWithoutQueryRaw();
    expect(response.status()).toBe(404);
});






