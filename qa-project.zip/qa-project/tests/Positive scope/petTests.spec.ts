import { test, expect } from '@playwright/test';
import { PetClient } from "../../clients/PetApiClient";
import { petCreateRequestBody, PetStatuses } from "../../fixtures/pet";
import { Pet, DeleteBody } from '../../types/pet';
import { petCreatedSchema, petFindByIdSchema, petDeletedSchema, petByStatusArraySchema } from '../../schemas/pet';
import { validateResponse} from '../../helpers/validateResponse';
import { generatePet, generateUpdatedPet } from '../../utils/PositiveData/dataGeneratorPet';



test('Add a new pet to the store', async ({request}) => {
    const petClient = new PetClient(request);
    const response = await petClient.addPet(petCreateRequestBody);
    const body = await validateResponse<Pet>(response,200,petCreatedSchema);
    expect(body.id).toBe(petCreateRequestBody.id);
    expect(body.status).toBe(petCreateRequestBody.status);
    expect(body.name).toBe(petCreateRequestBody.name);

});

test('Update an existing pet', async ({request}) => {
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
        await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const updatedPet = generateUpdatedPet(pet.id);
    const response = await petClient.updatePet(updatedPet);
    const body = await validateResponse<Pet>(response,200,petCreatedSchema);
    expect(body.id).toBe(updatedPet.id);
    expect(body.status).toBe(updatedPet.status);
    expect(body.name).toBe(updatedPet.name);
    
});


for (const PetStat of PetStatuses) { 
test(`Find Pets by status: ${PetStat}`, async ({request}) => { 
    const petClient = new PetClient(request);
    const response = await petClient.petByStatus(PetStat);
    const body = await validateResponse<Pet[]>(response,200,petByStatusArraySchema);
    expect(body.length).toBeGreaterThan(0);
    for (const pet of body) {
        expect(pet.status).toBe(PetStat);
    };
});
};

test('Find pet by ID', async ({ request }) => {
    const petClient = new PetClient(request);
    const pet = generatePet();

    const createResponse = await petClient.addPet(pet);
        await validateResponse<Pet>(createResponse,200,petFindByIdSchema);
    const response = await petClient.petById(pet.id);
    const body = await validateResponse<Pet>(response,200,petFindByIdSchema);
    expect(body.id).toBe(pet.id);
    expect(body.name).toBe(pet.name);
});


//test('Updates a pet in the store with form data', async ({request}) => { 
//    const petClient = new PetClients(request);
//     const response = await petClient.updatePetByQuery(queryUpdateBody);
//     expect(response.status()).toBe(200);
//     const data = await response.json();
//     //добавить еще проверки
// });

test('Deletes a pet', async ({request}) => {
    const petClient = new PetClient(request);
    const pet = generatePet();
    const createResponse = await petClient.addPet(pet);
        await validateResponse<Pet>(createResponse,200,petCreatedSchema);
    const deleteResponse = await petClient.deletePetById(pet.id);
    const body = await validateResponse<DeleteBody>(deleteResponse,200,petDeletedSchema);
    expect(body.type).toBeTruthy();
    expect(body.code).toBe(200);
    expect(body.message).toBe(String(pet.id));
    
});

test('PET lifecycle:', async ({request}) => { 
    const petClient = new PetClient(request);
    const pet = generatePet();

    const createPet = await petClient.addPet(pet);
    const createdBody = await validateResponse<Pet>(createPet,200,petCreatedSchema);
    expect(createdBody.id).toBe(pet.id);
    expect(createdBody.status).toBe(pet.status);
    expect(createdBody.name).toBe(pet.name);

    const getcreatedPet = await petClient.petById(createdBody.id);
    const getcreatedPetresponse = await validateResponse<Pet>(getcreatedPet,200,petFindByIdSchema);
    expect(getcreatedPetresponse.id).toBe(createdBody.id);


    const updatedPet = generateUpdatedPet(createdBody.id);
    const updatePet = await petClient.updatePet(updatedPet);
    const updatedBody = await validateResponse<Pet>(updatePet,200,petCreatedSchema);
    expect(updatedBody.id).toBe(updatedPet.id);
    expect(updatedBody.status).toBe(updatedPet.status);
    expect(updatedBody.name).toBe(updatedPet.name);

    const findByStatus = await petClient.petByStatus(updatedBody.status);
    const findByStatusresponse = await validateResponse<Pet[]>(findByStatus,200,petByStatusArraySchema);
    expect(findByStatusresponse.length).toBeGreaterThan(0);
    for (const pet of findByStatusresponse) {
        expect(pet.status).toBe(updatedBody.status)
    };

    const findById = await petClient.petById(updatedBody.id);
    const findByIdResponse = await validateResponse<Pet>(findById,200,petFindByIdSchema);
    expect(findByIdResponse.id).toBe(updatedBody.id);

    const deletePet = await petClient.deletePetById(updatedBody.id);
    const deletedPetResponse = await validateResponse<DeleteBody>(deletePet,200,petDeletedSchema);
    expect(deletedPetResponse.code).toBeTruthy();
    expect(deletedPetResponse.type).toBeTruthy();
    expect(deletedPetResponse.message).toBeTruthy();
    expect(deletedPetResponse.code).toBe(200);
    expect(deletedPetResponse.message).toBe(String(pet.id));
    
    const getDeletedResponse = await petClient.petById(pet.id);
    expect(getDeletedResponse.status()).toBe(404);

    
});