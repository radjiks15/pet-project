import {test, expect} from '@playwright/test';
import { UserClass } from '../../clients/UserApiClient';
import { validateResponse } from '../../helpers/validateResponse';
import { createUserSchema,getUserByUsernameSchema,updateUserSchema, deleteUserSchema, loginUserSchema, logoutUserSchema } from '../../schemas/user';
import { User,CreateUserResponse, getUserResponse, updateUserResponse, deleteUserResponse, userLoginResponse, userLogoutResponse } from '../../types/user'; 
import {generateUser, generateUpdatedUser} from '../../utils/PositiveData/dataGeneratorUser';
import { updateUserRequestBody } from '../../fixtures/user';


test ('Create User', async ({request}) => {
    const userClient = new UserClass(request);
    const requestBody = generateUser();
    const response = await userClient.createUser(requestBody);
    const data = await validateResponse<CreateUserResponse>(response,200,createUserSchema);
    expect(data.code).toBe(200);
    expect(data.type).toBeTruthy();
    expect(data.message).toBe(String(requestBody.id));

});

test('Get user by user name', async ({request}) => {
    const userClient = new UserClass(request);
    const requestBody = generateUser();
    const response = await userClient.createUser(requestBody);
    const data = await validateResponse<CreateUserResponse>(response,200,createUserSchema);
    const getResponse = await userClient.getUserByName(requestBody.username);
    const dataResponse = await validateResponse<getUserResponse>(getResponse,200,getUserByUsernameSchema);
    expect(dataResponse.id).toBe(requestBody.id);
    expect(dataResponse.username).toBe(requestBody.username);
    expect(dataResponse.firstName).toBe(requestBody.firstName);
    expect(dataResponse.lastName).toBe(requestBody.lastName);
    expect(dataResponse.email).toBe(requestBody.email);
    expect(dataResponse.password).toBe(requestBody.password);
    expect(dataResponse.phone).toBe(requestBody.phone);
    expect(dataResponse.userStatus).toBe(requestBody.userStatus);
});

test('Logs user into the system', async ({request}) => {
    const userClient = new UserClass(request);
    const requestBody = generateUser();
    const response = await userClient.createUser(requestBody);
    const data = await validateResponse<CreateUserResponse>(response,200,createUserSchema);
    const loginResponse = await userClient.userLogin(requestBody.username, requestBody.password);
    const dataAfterLogin = await validateResponse<userLoginResponse>(loginResponse,200,loginUserSchema);
    expect(dataAfterLogin.message).toContain('logged in user session:');
    expect(dataAfterLogin.code).toBe(200);
    expect(dataAfterLogin.type).toBeTruthy();

});

test('Logs out current logged in user session', async ({request}) => {
    const userClient = new UserClass(request);
    const requestBody = generateUser();
    const response = await userClient.createUser(requestBody);
    const data = await validateResponse<CreateUserResponse>(response,200,createUserSchema);
    const loginResponse = await userClient.userLogin(requestBody.username, requestBody.password);
    const dataAfterLogin = await validateResponse<userLoginResponse>(loginResponse,200,loginUserSchema);
    expect(dataAfterLogin.message).toContain('logged in user session:');
    const logoutResponse = await userClient.userLogout();
    const dataAfterLogout = await validateResponse<userLogoutResponse>(logoutResponse,200,logoutUserSchema);
    expect(dataAfterLogout.message).toBe('ok');
    expect(dataAfterLogout.type).toBeTruthy();
    expect(dataAfterLogout.code).toBe(200);
});

test('Updated user', async ({request}) => {
    const userClient = new UserClass(request);
    const requestBody = generateUser();
    const response = await userClient.createUser(requestBody);
    const data = await validateResponse<CreateUserResponse>(response,200,createUserSchema);
    const updatedUserBody = generateUpdatedUser(requestBody.id);
    const updatedResponse = await userClient.userUpdate(requestBody.username,updatedUserBody);
    const updatedData = await validateResponse<updateUserResponse>(updatedResponse,200,updateUserSchema)
    expect(updatedData.code).toBe(200);
    expect(updatedData.type).toBeTruthy();
    expect(updatedData.message).toBe(String(requestBody.id));
    
});

test('Delete user', async ({request}) => {
    const userClient = new UserClass(request);
    const requestBody = generateUser();
    const response = await userClient.createUser(requestBody);
    const data = await validateResponse<CreateUserResponse>(response,200,createUserSchema);
    const deleteResponse = await userClient.userDelete(requestBody.username);
    const deletedData = await validateResponse<deleteUserResponse>(deleteResponse,200,deleteUserSchema);
    expect(deletedData.code).toBe(200);
    expect(deletedData.message).toContain(requestBody.username);
    expect(deletedData.type).toBeTruthy();
});

test('USER lifecycle:', async ({request}) => {
    const userClient = new UserClass(request);
    const requestBody = generateUser();
    const response = await userClient.createUser(requestBody);
    const data = await validateResponse<CreateUserResponse>(response,200,createUserSchema);
    expect(data.code).toBe(200);
    expect(data.type).toBeTruthy();
    expect(data.message).toBe(String(requestBody.id));

    const getResponse = await userClient.getUserByName(requestBody.username);
    const dataResponse = await validateResponse<getUserResponse>(getResponse,200,getUserByUsernameSchema);
    expect(dataResponse.id).toBe(requestBody.id);
    expect(dataResponse.username).toBe(requestBody.username);
    expect(dataResponse.firstName).toBe(requestBody.firstName);
    expect(dataResponse.lastName).toBe(requestBody.lastName);
    expect(dataResponse.email).toBe(requestBody.email);
    expect(dataResponse.password).toBe(requestBody.password);
    expect(dataResponse.phone).toBe(requestBody.phone);
    expect(dataResponse.userStatus).toBe(requestBody.userStatus);

    const updatedUserBody = generateUpdatedUser(dataResponse.id);
    const updatedResponse = await userClient.userUpdate(dataResponse.username,updatedUserBody);
    const updatedData = await validateResponse<updateUserResponse>(updatedResponse,200,updateUserSchema)
    expect(updatedData.code).toBe(200);
    expect(updatedData.type).toBeTruthy();
    expect(updatedData.message).toBe(String(dataResponse.id));


    const getafterUpdateResponse = await userClient.getUserByName(updatedUserBody.username);
    const dataafterUpdateResponse = await validateResponse<getUserResponse>(getafterUpdateResponse,200,getUserByUsernameSchema);
    expect(dataafterUpdateResponse.id).toBe(updatedUserBody.id);
    expect(dataafterUpdateResponse.username).toBe(updatedUserBody.username);
    expect(dataafterUpdateResponse.firstName).toBe(updatedUserBody.firstName);
    expect(dataafterUpdateResponse.lastName).toBe(updatedUserBody.lastName);
    expect(dataafterUpdateResponse.email).toBe(updatedUserBody.email);
    expect(dataafterUpdateResponse.password).toBe(updatedUserBody.password);
    expect(dataafterUpdateResponse.phone).toBe(updatedUserBody.phone);
    expect(dataafterUpdateResponse.userStatus).toBe(updatedUserBody.userStatus);


    const loginResponse = await userClient.userLogin(dataafterUpdateResponse.username, dataafterUpdateResponse.password);
    const dataAfterLogin = await validateResponse<userLoginResponse>(loginResponse,200,loginUserSchema);
    expect(dataAfterLogin.message).toContain('logged in user session:');
    expect(dataAfterLogin.code).toBe(200);
    expect(dataAfterLogin.type).toBeTruthy();


    const logoutResponse = await userClient.userLogout();
    const dataAfterLogout = await validateResponse<userLogoutResponse>(logoutResponse,200,logoutUserSchema);
    expect(dataAfterLogout.message).toBe('ok');
    expect(dataAfterLogout.type).toBeTruthy();
    expect(dataAfterLogout.code).toBe(200);

    
    const deleteResponse = await userClient.userDelete(dataafterUpdateResponse.username);
    const deletedData = await validateResponse<deleteUserResponse>(deleteResponse,200,deleteUserSchema);
    expect(deletedData.code).toBe(200);
    expect(deletedData.message).toContain(dataafterUpdateResponse.username);
    expect(deletedData.type).toBeTruthy();


    const getResponseAfterDeletingUser = await userClient.getUserByName(dataafterUpdateResponse.username);
    expect(getResponseAfterDeletingUser.status()).toBe(404);

});