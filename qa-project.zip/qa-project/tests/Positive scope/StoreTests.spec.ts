import {test, expect } from '@playwright/test';
import { StoreClient } from "../../clients/StoreApiClient";
import { storeOrderSchema, storeOrderDelSchema, storeInventory, storeOrderById} from "../../schemas/store";
import {env} from '../../config/env'
import {placeOrderRequestBody} from '../../utils/PositiveData/dataGeneratorStore'
import { validateAdditionalItems } from 'ajv/dist/vocabularies/applicator/additionalItems';
import {storeOrder, InventoryResponse, fetchOrderById, DeleteOrder} from '../../types/store'
import { validateResponse } from '../../helpers/validateResponse';





test ('Place an order for a pet', async ({request}) => {
    const storeClient = new StoreClient(request);
    const ord = placeOrderRequestBody();

    const response = await storeClient.placeOrder(ord);
    const body = await validateResponse<storeOrder>(response,200,storeOrderSchema);
    expect(body.id).toBe(ord.id);
    expect(body.petId).toBe(ord.petId);
    expect(body.quantity).toBe(ord.quantity);
    expect(body.status).toBe(ord.status);
    expect(body.complete).toBe(ord.complete);
    expect(new Date(body.shipDate).getTime()).toBe(new Date(ord.shipDate).getTime());


});

test('Map of inventories by status', async ({request}) => {
    const storeClient = new StoreClient(request);
    const response = await storeClient.petsStatusCodes();
    const body = await validateResponse<InventoryResponse>(response,200,storeInventory);
    
});

test('Find purchase order by ID', async ({request}) => {
    const storeClient = new StoreClient(request);
    const ord = placeOrderRequestBody();

    const response = await storeClient.placeOrder(ord);
    const body = await validateResponse<storeOrder>(response,200,storeOrderSchema);
    expect(body.id).toBe(ord.id);

    const responseId = await storeClient.getByOrderId(body.id);
    const responseBody = await validateResponse<fetchOrderById>(responseId,200,storeOrderById);
    expect(responseBody.id).toBe(body.id);
    expect(responseBody.petId).toBe(body.petId);
    expect(responseBody.quantity).toBe(body.quantity);
    expect(responseBody.status).toBe(body.status);
    expect(responseBody.complete).toBe(body.complete);
    expect(new Date(responseBody.shipDate).getTime()).toBe(new Date(body.shipDate).getTime());
});

test('Delete purchase order by ID', async ({request}) => {
    const storeClient = new StoreClient(request);
    const ord = placeOrderRequestBody();

    const response = await storeClient.placeOrder(ord);
    const body = await validateResponse<storeOrder>(response,200,storeOrderSchema);
    expect(body.id).toBe(ord.id);

    const responseId = await storeClient.deleteByOrderId(body.id);
    const respBody = await validateResponse<DeleteOrder>(responseId,200,storeOrderDelSchema);
    expect(respBody.code).toBe(200);
    expect(respBody.message).toBe(String(body.id));
    expect(respBody.type).toBeTruthy();

});

test('STORE lifecycle:', async ({request}) => { 
    const storeClient = new StoreClient(request);
    const ord = placeOrderRequestBody();

    const response = await storeClient.placeOrder(ord);
    const body = await validateResponse<storeOrder>(response,200,storeOrderSchema);
    expect(body.id).toBe(ord.id);
    expect(body.petId).toBe(ord.petId);
    expect(body.quantity).toBe(ord.quantity);
    expect(body.status).toBe(ord.status);
    expect(body.complete).toBe(ord.complete);
    expect(new Date(body.shipDate).getTime()).toBe(new Date(ord.shipDate).getTime());


    const responseId = await storeClient.getByOrderId(body.id);
    const responseBody = await validateResponse<fetchOrderById>(responseId,200,storeOrderById);
    expect(responseBody.id).toBe(body.id);
    expect(responseBody.petId).toBe(body.petId);
    expect(responseBody.quantity).toBe(body.quantity);
    expect(responseBody.status).toBe(body.status);
    expect(responseBody.complete).toBe(body.complete);
    expect(new Date(responseBody.shipDate).getTime()).toBe(new Date(body.shipDate).getTime());


    const responseDel = await storeClient.deleteByOrderId(body.id);
    const responsebodyDel = await validateResponse<DeleteOrder>(responseDel,200,storeOrderDelSchema);
    expect(responsebodyDel.code).toBe(200);
    expect(responsebodyDel.message).toBe(String(body.id));
    expect(responsebodyDel.type).toBeTruthy();

    const repeatresponse = await storeClient.getByOrderId(body.id);
    expect(repeatresponse.status()).toBe(404);




})
