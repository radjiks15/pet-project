import { APIResponse } from "@playwright/test";
import {AnySchema} from 'ajv';
import {expectStatus} from "./expectStatus"
import { expectSchema } from "./expectSchema";
import { parseResponse } from "./parseResponse";

export async function validateResponse<T>(
    response:APIResponse,
    expectedStatus:number,
    schema: AnySchema): Promise<T> {

    expectStatus(response, expectedStatus);

    const body = await parseResponse<T>(response);
    
    expectSchema(body, schema);
    
    return body;

}

