import { expect } from '@playwright/test';
import Ajv, { AnySchema } from 'ajv'; 

const ajv = new Ajv ({
    allErrors:true
});

export function expectSchema( data:unknown, schema: AnySchema) :void { 
    const validate = ajv.compile(schema);
    const isValid = validate(data);

    expect(
        isValid,
        JSON.stringify(validate.errors, null, 2)
    ).toBe(true);

}
