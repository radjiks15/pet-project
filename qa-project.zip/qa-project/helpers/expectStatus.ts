import { APIResponse, expect } from "@playwright/test";

export function expectStatus(response: APIResponse, expectStatus:number): void {
        expect(response.status()).toBe(expectStatus);
 }