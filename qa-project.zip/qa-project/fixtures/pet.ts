import {Pet} from '../types/pet'

export const petCreateRequestBody: Pet = {
  "id": 1912391231,
  "category": {
    "id": 1,
    "name": "dogs"
  },
  "name": "doggie",
  "photoUrls": [
    "photoUrl_1",
    "photoUrl_2"
  ],
  "tags": [
    {
      "id": 1,
      "name": "pretty_dogs"
    }
  ],
  "status": "available"
};

export const petUpdateRequestBody: Pet = {
    "id": 922337201,
  "category": {
    "id": 1,
    "name": "dogsiki"
  },
  "name": "doggie",
  "photoUrls": [
    "photoUrl_1",
    "photoUrl_2",
    "photoUrl_3"
  ],
  "tags": [
    {
      "id": 1,
      "name": "pretty_dogsiki"
    }
  ],
  "status": "available"
};

// Можно еще в types добавить типизацию для этих переменных
export const queryUpdateName = "Doggus";
export const queryUpdateStatus = "sold";
export const queryUpdatePetId = 9223370;
export const queryUpdateBody = {};
export const petIdforDelete = 9223370;

export const PetStatuses : Pet['status'][] = ['available', 'sold', 'pending'];

