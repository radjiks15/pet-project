import { storeOrder } from "../types/store";


export const placeOrderRequestBody: storeOrder = {
  "id": 1,
  "petId": 1,
  "quantity": 1,
  "shipDate": "2026-08-14T12:23:44.540Z",
  "status": "placed",
  "complete": true
};


// Можно добавить типизацию для этих переменных
export const orderIdForFind = 1;
export const orderIdForDelete = 1;
