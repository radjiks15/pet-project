export const petStatus = [
    {name: 'Invalid status !=enum',
     status: 'ready'},

    { name: 'Empty status field',
    status: ''
    },
];

export const PetId = [
    {name: 'String id',
    id: 'invalid'
    },

    {name: 'Empty query field',
    id: ''
    }
];






