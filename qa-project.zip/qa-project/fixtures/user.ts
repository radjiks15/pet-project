import {User} from '../types/user'

export const createUserRequestBody: User = {
    "id": 99,
    "username": "Danik123",
    "firstName": "Danik",
    "lastName": "Danikov",
    "email": "email@email.com",
    "password": "999",
    "phone": "+8999898988",
    "userStatus": 0
};

export const updateUserRequestBody: User = {
  "id": 0,
  "username": "Danik333",
  "firstName": "Danik",
  "lastName": "Danikov",
  "email": "emailemail@email.com",
  "password": "999",
  "phone": "+8999898988",
  "userStatus": 0
};


// Можно добавить типизацию для этих переменных
export const queryForUpdate = "Danik123";
export const queryForDelete = "Danik123";

export const userNameLogin = "Danik123" ;
export const userPasswordLogin = "999";